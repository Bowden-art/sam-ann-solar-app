# Sam-Ann Solar Investment — Android app build guide

## What this package contains

- `android-app/`: a native Android WebView app project (Java + Gradle).
- The original Grok website project remains in the root and is not replaced.
- The app keeps the existing website pages and server-backed features by loading the deployed HTTPS website: product catalogue/details, quote requests, login, admin, contact and WhatsApp links.

## Important requirement

The uploaded project is a full-stack TanStack Start app with server routes, authentication and database code. It cannot safely be turned into a standalone offline APK by copying its browser files into the phone. The website must first be deployed to an HTTPS URL with its backend and database configured. The APK then opens that website in an Android app window.

## Build the APK on a computer

1. Install Android Studio (current stable), Android SDK Platform 35, and JDK 17. Open the `android-app` folder in Android Studio and allow Gradle sync.
2. Deploy the original website project (the root folder) to a host that supports its TanStack Start/Nitro server output. Configure its production environment and persistent PostgreSQL database according to the host's requirements. Do not publish database credentials inside the Android app.
3. Set the website URL during the build. From a terminal in `android-app`, run:

   ```bash
   ./gradlew assembleDebug -PSITE_URL=https://YOUR-REAL-DOMAIN.example
   ```

   On Windows Command Prompt, use `gradlew.bat assembleDebug -PSITE_URL=https://YOUR-REAL-DOMAIN.example`.

   Replace the example with the real HTTPS domain; do not include a trailing slash unless the host requires it.
4. The debug APK will be at `android-app/app/build/outputs/apk/debug/app-debug.apk`. Install it on an Android phone to test sign-in, products, quotation requests, admin access and WhatsApp links.
5. For a shareable release APK, configure signing in Android Studio using **Build > Generate Signed Bundle / APK**. Keep the signing key private.

## Security and functionality notes

- The wrapper only keeps navigation inside the app for the configured website host. External HTTPS links, WhatsApp, phone and email links open through Android.
- Login and admin permissions must be enforced by the website server. Hiding the admin screen in the app is not security.
- Use HTTPS and a production database. Test that orders/quotes persist after restarting the app and that customer accounts cannot read other customers' records.
- The app requires an internet connection because the server and database remain hosted with the website.
- This environment did not have Android SDK/Gradle installed, and the website's real deployed URL was not included in the ZIP. Therefore a working APK cannot be honestly produced until those two requirements are met. The source project is prepared for that final build.
