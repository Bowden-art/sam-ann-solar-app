import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ProductCard } from "@/components/product-card";
import { listCatalogue } from "@/lib/solar.functions";
import { AVAILABILITY, CATEGORIES, isCategory } from "@/lib/site";
import { fieldClass } from "@/lib/ui";

type ProductSearch = { cat?: string };

export const Route = createFileRoute("/products")({
  validateSearch: (search: Record<string, unknown>): ProductSearch => {
    const cat = typeof search.cat === "string" && isCategory(search.cat) ? search.cat : undefined;
    return cat ? { cat } : {};
  },
  loader: () => listCatalogue(),
  pendingComponent: ProductsPending,
  head: () => ({
    meta: [
      { title: "Products · Sam-Ann Solar Investment" },
      {
        name: "description",
        content:
          "Lumen Green solar panels, LiFePO4 batteries, three-phase inverters, mounting, cables and integrated kits in Lungi.",
      },
    ],
  }),
  component: ProductsPage,
});

function ProductsPending() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <div className="h-10 w-48 animate-pulse rounded-md bg-line" />
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 6 }).map((_, index) => (
          <div key={index} className="h-80 animate-pulse rounded-lg bg-snow" />
        ))}
      </div>
    </div>
  );
}

function ProductsPage() {
  const { products } = Route.useLoaderData();
  const search = Route.useSearch();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState(search.cat ?? "all");
  const [stock, setStock] = useState("all");

  useEffect(() => {
    setCategory(search.cat ?? "all");
  }, [search.cat]);

  const visible = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return products.filter((product) => {
      if (category !== "all" && product.category !== category) return false;
      if (stock !== "all" && product.availability !== stock) return false;
      if (!needle) return true;
      const haystack = `${product.name} ${product.summary} ${product.description}`.toLowerCase();
      return haystack.includes(needle);
    });
  }, [products, query, category, stock]);

  return (
    <main className="mx-auto max-w-6xl px-4 py-8">
      <p className="text-sm font-semibold tracking-wide text-green uppercase">Catalogue</p>
      <h1 className="font-display text-5xl font-semibold text-navy">Lumen Green products</h1>
      <p className="mt-2 max-w-2xl text-ink">
        Prices stay blank until the Sam-Ann office sets them. Availability can be confirmed on WhatsApp or with a
        quotation.
      </p>

      <div className="mt-6 grid gap-3 lg:grid-cols-[1fr_14rem]">
        <label className="block">
          <span className="sr-only">Search products</span>
          <input
            className={fieldClass}
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search panels, batteries, inverters…"
            type="search"
          />
        </label>
        <label className="block">
          <span className="sr-only">Availability</span>
          <select className={fieldClass} value={stock} onChange={(event) => setStock(event.target.value)}>
            <option value="all">Any availability</option>
            {AVAILABILITY.map((item) => (
              <option key={item.id} value={item.id}>
                {item.label}
              </option>
            ))}
          </select>
        </label>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <FilterChip active={category === "all"} onClick={() => setCategory("all")}>
          All
        </FilterChip>
        {CATEGORIES.map((item) => (
          <FilterChip key={item.id} active={category === item.id} onClick={() => setCategory(item.id)}>
            {item.label}
          </FilterChip>
        ))}
      </div>

      {visible.length === 0 ? (
        <p className="mt-10 rounded-lg border border-line bg-snow px-4 py-8 text-center text-muted">
          Nothing matches that search. Clear the filters or send a general quotation.
        </p>
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {visible.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </main>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        active
          ? "min-h-11 rounded-md bg-navy px-3 text-sm font-semibold text-snow"
          : "min-h-11 rounded-md border border-line bg-snow px-3 text-sm font-semibold text-navy"
      }
    >
      {children}
    </button>
  );
}
