import { useState, type FormEvent } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { authClient, GROK_PROVIDERS, signIn } from "@/lib/auth/client";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { btnLine, btnPrimary, fieldClass, labelClass } from "@/lib/ui";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [{ title: "Office sign in · Sam-Ann Solar Investment" }],
  }),
  component: LoginPage,
});

function LoginPage() {
  const { user, isPending } = useCurrentUserState();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [providerError, setProviderError] = useState<string | null>(null);

  if (isPending) {
    return (
      <main className="mx-auto max-w-md px-4 py-16">
        <div className="h-72 animate-pulse rounded-lg bg-snow" />
      </main>
    );
  }

  if (user) {
    return (
      <main className="mx-auto max-w-md px-4 py-16">
        <h1 className="font-display text-4xl font-semibold text-navy">You are signed in</h1>
        <p className="mt-2 text-sm text-muted">{user.primaryEmail ?? user.displayName ?? "Staff account"}</p>
        <div className="mt-4">
          <UserButton />
        </div>
        <Link to="/admin" className={`${btnPrimary} mt-6`}>
          Open the office desk
        </Link>
      </main>
    );
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    if (password.length < 8) {
      setError("Use at least 8 characters for the password.");
      return;
    }
    setBusy(true);
    try {
      const result =
        mode === "up"
          ? await authClient.signUp.email({
              email,
              password,
              name: name.trim() || "Sam-Ann staff",
              callbackURL: "/admin",
            })
          : await authClient.signIn.email({ email, password, callbackURL: "/admin" });
      if (result.error) {
        setError(result.error.message ?? "Sign-in failed.");
        setBusy(false);
        return;
      }
      await navigate({ to: "/admin" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign-in failed.");
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto grid max-w-md gap-6 px-4 py-10">
      <div>
        <p className="text-sm font-semibold tracking-wide text-green uppercase">Staff only</p>
        <h1 className="font-display text-5xl font-semibold text-navy">Office sign in</h1>
        <p className="mt-2 text-sm text-muted">
          Customers do not need an account.{" "}
          <Link to="/quote" className="font-semibold text-green underline-offset-2 hover:underline">
            Request a quote
          </Link>{" "}
          or WhatsApp the office instead.
        </p>
      </div>
      <div className="grid gap-2">
        {GROK_PROVIDERS.map((provider) => (
          <button
            key={provider.providerId}
            type="button"
            className={btnLine}
            onClick={() => {
              setProviderError(null);
              void signIn(provider.providerId, { callbackURL: "/admin" }).catch((err: unknown) => {
                setProviderError(err instanceof Error ? err.message : "Sign-in failed.");
              });
            }}
          >
            Continue with {provider.label}
          </button>
        ))}
        {providerError ? (
          <p className="text-sm font-semibold text-navy" role="alert">
            {providerError}
          </p>
        ) : null}
      </div>
      <form className="rounded-lg border border-line bg-snow p-4" onSubmit={onSubmit}>
        <div className="grid grid-cols-2 gap-2">
          <button type="button" className={mode === "in" ? btnPrimary : btnLine} onClick={() => setMode("in")}>
            Sign in
          </button>
          <button type="button" className={mode === "up" ? btnPrimary : btnLine} onClick={() => setMode("up")}>
            Create account
          </button>
        </div>
        {mode === "up" ? (
          <label className="mt-4 block">
            <span className={labelClass}>Name</span>
            <input className={fieldClass} value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" />
          </label>
        ) : null}
        <label className="mt-4 block">
          <span className={labelClass}>Email</span>
          <input
            className={fieldClass}
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            autoComplete="email"
            required
          />
        </label>
        <label className="mt-4 block">
          <span className={labelClass}>Password</span>
          <input
            className={fieldClass}
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            autoComplete={mode === "up" ? "new-password" : "current-password"}
            required
          />
        </label>
        {error ? (
          <p className="mt-3 text-sm font-semibold text-navy" role="alert">
            {error}
          </p>
        ) : null}
        <button type="submit" className={`${btnPrimary} mt-4 w-full`} disabled={busy}>
          {busy ? "Please wait…" : mode === "up" ? "Create staff account" : "Sign in with email"}
        </button>
      </form>
    </main>
  );
}
