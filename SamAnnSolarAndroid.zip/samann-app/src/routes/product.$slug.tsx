import { createFileRoute, Link } from "@tanstack/react-router";
import { getProduct } from "@/lib/solar.functions";
import { availabilityLabel, categoryLabel, safeImage } from "@/lib/site";
import { useQuoteStore } from "@/lib/quote-store";
import { btnLine, btnPrimary, btnSun } from "@/lib/ui";
import { productEnquiryMessage, whatsappLink } from "@/lib/whatsapp";

export const Route = createFileRoute("/product/$slug")({
  loader: ({ params }) => getProduct({ data: params.slug }),
  pendingComponent: () => (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <div className="h-80 animate-pulse rounded-lg bg-snow" />
    </div>
  ),
  head: ({ loaderData }) => ({
    meta: [
      {
        title: loaderData ? `${loaderData.name} · Sam-Ann Solar Investment` : "Product · Sam-Ann Solar Investment",
      },
    ],
  }),
  component: ProductPage,
});

function ProductPage() {
  const product = Route.useLoaderData();
  const added = useQuoteStore((state) => (product ? state.items.some((item) => item.id === product.id) : false));
  const add = useQuoteStore((state) => state.add);

  if (!product) {
    return (
      <main className="mx-auto max-w-3xl px-4 py-16 text-center">
        <h1 className="font-display text-4xl font-semibold text-navy">This product is not in the catalogue</h1>
        <Link to="/products" className={`${btnPrimary} mt-6`}>
          Back to products
        </Link>
      </main>
    );
  }

  return (
    <main className="mx-auto grid max-w-5xl gap-8 px-4 py-8 lg:grid-cols-2">
      <div className="flex min-h-72 items-center justify-center rounded-lg border border-line bg-snow p-6">
        <img
          src={safeImage(product.imageUrl)}
          alt={product.name}
          className="max-h-96 w-full object-contain"
        />
      </div>
      <div>
        <p className="text-sm font-semibold tracking-wide text-green uppercase">{categoryLabel(product.category)}</p>
        <h1 className="mt-2 font-display text-5xl leading-none font-semibold text-navy">{product.name}</h1>
        <p className="mt-4 text-ink">{product.description}</p>
        <p className="mt-4 font-display text-3xl font-semibold text-navy tabular-nums">
          {product.priceLabel ?? "Price on request"}
        </p>
        <p className="mt-1 text-sm font-semibold text-green">{availabilityLabel(product.availability)}</p>
        {product.specs.length > 0 ? (
          <dl className="mt-6 divide-y divide-line rounded-lg border border-line bg-snow">
            {product.specs.map((spec) => (
              <div key={`${spec.label}-${spec.value}`} className="grid gap-1 px-4 py-3 sm:grid-cols-2">
                <dt className="text-sm text-muted">{spec.label}</dt>
                <dd className="text-sm font-semibold text-navy">{spec.value}</dd>
              </div>
            ))}
          </dl>
        ) : (
          <p className="mt-6 text-sm text-muted">The office has not published extra specifications for this item yet.</p>
        )}
        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <button
            type="button"
            className={btnPrimary}
            onClick={() => add({ id: product.id, name: product.name })}
          >
            {added ? "Added to quotation" : "Add to quotation"}
          </button>
          <Link to="/quote" className={btnSun}>
            Request a quote
          </Link>
          <a
            className={btnLine}
            href={whatsappLink(productEnquiryMessage(product.name))}
            target="_blank"
            rel="noopener noreferrer"
          >
            WhatsApp this product
          </a>
        </div>
      </div>
    </main>
  );
}
