import { createFileRoute, Link } from "@tanstack/react-router";
import { ADDRESS_FULL, COMPANY, SERVICES } from "@/lib/site";
import { btnPrimary } from "@/lib/ui";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About · Sam-Ann Solar Investment" },
      {
        name: "description",
        content:
          "Sam-Ann Solar Investment is the official Lumen Green agent in Lungi, on Main Port Loko Road, Gbaneh Bana.",
      },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <main>
      <section className="bg-navy text-snow">
        <div className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-12 lg:grid-cols-[1.2fr_0.8fr]">
          <div>
            <p className="text-sm font-semibold tracking-wide text-sun uppercase">About the office</p>
            <h1 className="mt-2 font-display text-5xl font-semibold">Sam-Ann Solar Investment</h1>
            <p className="mt-4 max-w-xl text-snow/80">
              {COMPANY} is the official agent for Lumen Green at Lungi. Lumen Green products are from Shenzhen
              LumenGreen Technology Co., Ltd. Sales, installation support and after-sales are handled from{" "}
              {ADDRESS_FULL}.
            </p>
            <p className="mt-3 max-w-xl text-sm text-snow/70">
              The line serves homes, shops, businesses, offices, farms, schools and large projects in Lungi, Gbaneh
              Bana and communities along Main Port Loko Road.
            </p>
          </div>
          <div className="rounded-lg bg-snow p-3">
            <img src="/media/logo-lumen.jpg" alt="Lumen Green, Shenzhen LumenGreen Technology Co., Ltd." className="w-full" />
          </div>
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="font-display text-4xl font-semibold text-navy">What the office does</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((service) => (
            <article key={service.title} className="rounded-lg border border-line bg-snow p-4">
              <h3 className="font-display text-2xl font-semibold text-navy">{service.title}</h3>
              <p className="mt-2 text-sm text-ink">{service.body}</p>
            </article>
          ))}
        </div>
        <Link to="/quote" className={`${btnPrimary} mt-8`}>
          Request a quote
        </Link>
      </section>
      <section className="bg-snow">
        <div className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-12 lg:grid-cols-2">
          <img
            src="/media/flyer.jpg"
            alt="Sam-Ann Solar Investment flyer for Lumen Green products in Lungi"
            loading="lazy"
            className="mx-auto w-full max-w-sm rounded-lg border border-line"
          />
          <div>
            <h2 className="font-display text-4xl font-semibold text-navy">The Lungi flyer</h2>
            <p className="mt-3 text-ink">
              Product photographs and the ranges on this site come from the Sam-Ann flyer: 580W–600W modules, 15kWh
              and 16kWh LiFePO4 batteries, 4–15kW three-phase inverters, mounting, cables with MC4 connectors, and
              integrated kits. Prices are not printed on the flyer, so they are not invented here.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
