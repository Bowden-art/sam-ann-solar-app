import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Building2,
  Factory,
  Headset,
  Home,
  School,
  ShoppingBag,
  Sprout,
  Store,
  Truck,
  Wrench,
} from "lucide-react";
import { ProductCard } from "@/components/product-card";
import { listCatalogue } from "@/lib/solar.functions";
import {
  ADDRESS_LINE,
  CATEGORIES,
  DEFAULT_BANNER,
  PHONE_DISPLAY,
  PHONE_TEL,
  PROJECT_TYPES,
} from "@/lib/site";
import { btnGhost, btnPrimary, btnSun } from "@/lib/ui";
import { generalEnquiryMessage, whatsappLink } from "@/lib/whatsapp";

const ICONS = {
  homes: Home,
  shops: Store,
  offices: Building2,
  farms: Sprout,
  schools: School,
  projects: Factory,
} as const;

export const Route = createFileRoute("/")({
  loader: () => listCatalogue(),
  pendingComponent: HomePending,
  head: () => ({
    meta: [
      { title: "Sam-Ann Solar Investment · Lumen Green in Lungi" },
      {
        name: "description",
        content:
          "Official agent for Lumen Green at Lungi. Solar panels, batteries, inverters, mounting and kits. Call or WhatsApp +232 77 227530.",
      },
    ],
  }),
  component: HomePage,
});

function HomePending() {
  return (
    <div className="bg-navy">
      <div className="mx-auto max-w-6xl px-4 py-16">
        <div className="h-8 w-56 animate-pulse rounded-md bg-snow/15" />
        <div className="mt-4 h-16 max-w-xl animate-pulse rounded-md bg-snow/15" />
        <div className="mt-8 h-72 animate-pulse rounded-lg bg-snow/10" />
      </div>
    </div>
  );
}

function HomePage() {
  const { products, banner } = Route.useLoaderData();
  const eyebrow = banner?.active ? banner.eyebrow : DEFAULT_BANNER.eyebrow;
  const title = banner?.active ? banner.title : DEFAULT_BANNER.title;
  const body = banner?.active ? banner.body : DEFAULT_BANNER.body;
  const featured = products.filter((product) => product.featured);

  return (
    <main>
      <section className="bg-navy text-snow">
        <div className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-10 lg:grid-cols-2 lg:py-14">
          <div>
            <p className="inline-flex rounded-md bg-sun px-3 py-1 text-sm font-semibold text-navy">{eyebrow}</p>
            <p className="mt-5 font-display text-5xl leading-none font-bold tracking-wide sm:text-6xl">
              SAM-ANN <span className="text-sun">SOLAR</span> INVESTMENT
            </p>
            <h1 className="mt-4 font-display text-3xl leading-tight font-semibold text-snow sm:text-4xl">{title}</h1>
            <p className="mt-3 text-sm font-semibold tracking-wide text-sun uppercase">
              Reliable · Efficient · Long lasting
            </p>
            <p className="mt-3 max-w-xl text-snow/80">{body}</p>
            <p className="mt-3 text-sm text-snow/70">{ADDRESS_LINE}, Sierra Leone</p>
            <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
              <Link to="/products" className={btnPrimary}>
                Browse products
              </Link>
              <Link to="/quote" className={btnSun}>
                Request a quote
              </Link>
              <a className={btnGhost} href={whatsappLink(generalEnquiryMessage())} target="_blank" rel="noopener noreferrer">
                WhatsApp us
              </a>
            </div>
          </div>
          <div>
            <div className="overflow-hidden rounded-lg border border-snow/15 bg-navy-soft">
              <img
                src="/media/hero.jpg"
                alt="Lumen Green solar panels, storage batteries and inverters"
                width={504}
                height={510}
                fetchPriority="high"
                className="h-auto w-full"
              />
            </div>
            <div className="mt-3 flex items-center gap-3 rounded-lg bg-snow p-2">
              <img src="/media/logo-lumen.jpg" alt="Lumen Green" className="h-12 w-auto object-contain" />
              <p className="text-xs font-semibold tracking-wide text-navy uppercase">
                Clean energy · Brighter tomorrow
              </p>
            </div>
          </div>
        </div>
        <div className="border-t border-snow/10">
          <ul className="mx-auto grid max-w-6xl gap-px bg-snow/10 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: ShoppingBag, label: "Sales" },
              { icon: Wrench, label: "Installation support" },
              { icon: Headset, label: "After-sales support" },
              { icon: Truck, label: "Delivery" },
            ].map((item) => (
              <li key={item.label} className="flex items-center gap-3 bg-navy px-4 py-4 text-sm font-semibold">
                <item.icon className="size-5 text-sun" aria-hidden="true" />
                {item.label}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-12">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-sm font-semibold tracking-wide text-green uppercase">Catalogue</p>
            <h2 className="font-display text-4xl font-semibold text-navy">Featured Lumen Green products</h2>
          </div>
          <Link to="/products" className="text-sm font-semibold text-green underline-offset-2 hover:underline">
            View the full catalogue
          </Link>
        </div>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {featured.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      <section className="bg-snow">
        <div className="mx-auto max-w-6xl px-4 py-12">
          <h2 className="font-display text-4xl font-semibold text-navy">Shop by category</h2>
          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {CATEGORIES.map((category) => (
              <Link
                key={category.id}
                to="/products"
                search={{ cat: category.id }}
                className="rounded-lg border border-line bg-paper px-4 py-4 transition-colors duration-200 hover:border-green"
              >
                <p className="font-display text-2xl font-semibold text-navy">{category.label}</p>
                <p className="text-sm text-muted">{category.blurb}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="font-display text-4xl font-semibold text-navy">Ideal for</h2>
        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {PROJECT_TYPES.map((project) => {
            const Icon = ICONS[project.id];
            return (
              <Link
                key={project.id}
                to="/quote"
                search={{ for: project.id }}
                className="flex gap-3 rounded-lg border border-line bg-snow p-4 transition-colors duration-200 hover:border-green"
              >
                <span className="grid h-11 w-11 shrink-0 place-items-center rounded-md bg-green text-snow">
                  <Icon className="size-5" aria-hidden="true" />
                </span>
                <span>
                  <span className="block font-semibold text-navy">{project.label}</span>
                  <span className="block text-sm text-muted">{project.blurb}</span>
                </span>
              </Link>
            );
          })}
        </div>
      </section>

      <section className="bg-navy text-snow">
        <div className="h-1 bg-sun" />
        <div className="mx-auto flex max-w-6xl flex-col items-start gap-4 px-4 py-10 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="font-display text-4xl font-semibold">Call or WhatsApp now</h2>
            <p className="mt-1 text-snow/75">The office will confirm stock, price and a system that fits the site.</p>
          </div>
          <div className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
            <a className={btnSun} href={`tel:${PHONE_TEL}`}>
              {PHONE_DISPLAY}
            </a>
            <a className={btnGhost} href={whatsappLink(generalEnquiryMessage())} target="_blank" rel="noopener noreferrer">
              WhatsApp us
            </a>
          </div>
        </div>
      </section>
    </main>
  );
}
