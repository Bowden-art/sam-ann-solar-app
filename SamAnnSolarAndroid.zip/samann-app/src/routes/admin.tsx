import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { RedirectToSignIn, UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import {
  claimOffice,
  deleteProduct,
  getOfficeAccess,
  inviteStaff,
  listCatalogue,
  listEnquiries,
  removeInvite,
  removeStaff,
  saveBanner,
  saveProduct,
  updateEnquiryStatus,
  type Banner,
  type Enquiry,
  type OfficeAccess,
  type Product,
} from "@/lib/solar.functions";
import {
  AVAILABILITY,
  CATEGORIES,
  DEFAULT_BANNER,
  ENQUIRY_STATUSES,
  MEDIA_LIBRARY,
  availabilityLabel,
  categoryLabel,
  projectLabel,
  safeImage,
} from "@/lib/site";
import { btnLine, btnPrimary, btnSun, fieldClass, labelClass } from "@/lib/ui";
import { customerWhatsApp } from "@/lib/whatsapp";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [{ title: "Office desk · Sam-Ann Solar Investment" }],
  }),
  component: AdminPage,
});

function messageOf(error: unknown): string {
  if (error instanceof Error && error.message) return error.message;
  return "Something went wrong. Please try again.";
}

function AdminPage() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return (
      <main className="mx-auto max-w-6xl px-4 py-10">
        <div className="h-40 animate-pulse rounded-lg bg-snow" />
      </main>
    );
  }
  if (!user) return <RedirectToSignIn />;
  return <AdminDesk />;
}

type Draft = {
  id: string | null;
  name: string;
  category: string;
  summary: string;
  description: string;
  specsText: string;
  priceLabel: string;
  availability: string;
  imageUrl: string;
  featured: boolean;
  sortOrder: number;
};

function AdminDesk() {
  const [access, setAccess] = useState<OfficeAccess | null>(null);
  const [accessError, setAccessError] = useState<string | null>(null);
  const [tab, setTab] = useState<"enquiries" | "products" | "banner" | "team">("enquiries");
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [banner, setBanner] = useState<Banner | null>(null);
  const [deskError, setDeskError] = useState<string | null>(null);
  const [loadingDesk, setLoadingDesk] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setAccessError(null);
    getOfficeAccess()
      .then((next) => {
        if (!cancelled) setAccess(next);
      })
      .catch((error: unknown) => {
        if (!cancelled) setAccessError(messageOf(error));
      });
    return () => {
      cancelled = true;
    };
  }, [refreshKey]);

  useEffect(() => {
    if (!access || access.role === "none") return;
    let cancelled = false;
    setLoadingDesk(true);
    setDeskError(null);
    Promise.all([listEnquiries(), listCatalogue()])
      .then(([nextEnquiries, catalogue]) => {
        if (cancelled) return;
        setEnquiries(nextEnquiries);
        setProducts(catalogue.products);
        setBanner(catalogue.banner);
      })
      .catch((error: unknown) => {
        if (!cancelled) setDeskError(messageOf(error));
      })
      .finally(() => {
        if (!cancelled) setLoadingDesk(false);
      });
    return () => {
      cancelled = true;
    };
  }, [access, refreshKey]);

  return (
    <main className="mx-auto max-w-6xl px-4 py-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-sm font-semibold tracking-wide text-green uppercase">Staff</p>
          <h1 className="font-display text-5xl font-semibold text-navy">Office desk</h1>
        </div>
        <UserButton />
      </div>

      {accessError ? (
        <p className="mt-6 rounded-md border border-sun bg-sun/20 px-3 py-2 text-sm font-semibold text-navy" role="alert">
          {accessError}
        </p>
      ) : null}
      {!access && !accessError ? <div className="mt-6 h-40 animate-pulse rounded-lg bg-snow" /> : null}
      {access?.role === "none" && access.needsSetup ? (
        <ClaimForm
          onClaimed={() => setRefreshKey((value) => value + 1)}
        />
      ) : null}
      {access?.role === "none" && !access.needsSetup ? (
        <p className="mt-6 rounded-lg border border-line bg-snow p-4 text-sm">
          This account is not on the office list. The owner can invite {access.email ?? "your email"}.
        </p>
      ) : null}

      {access && access.role !== "none" ? (
        <>
          <div className="mt-6 flex flex-wrap gap-2">
            <TabButton active={tab === "enquiries"} onClick={() => setTab("enquiries")}>
              Enquiries ({enquiries.filter((item) => item.status === "new").length} new)
            </TabButton>
            <TabButton active={tab === "products"} onClick={() => setTab("products")}>
              Products
            </TabButton>
            <TabButton active={tab === "banner"} onClick={() => setTab("banner")}>
              Banner
            </TabButton>
            {access.role === "owner" ? (
              <TabButton active={tab === "team"} onClick={() => setTab("team")}>
                Staff
              </TabButton>
            ) : null}
          </div>
          {deskError ? (
            <p className="mt-4 text-sm font-semibold text-navy" role="alert">
              {deskError}
            </p>
          ) : null}
          {loadingDesk ? <div className="mt-4 h-24 animate-pulse rounded-lg bg-snow" /> : null}
          {tab === "enquiries" ? (
            <EnquiryList
              enquiries={enquiries}
              onChanged={() => setRefreshKey((value) => value + 1)}
            />
          ) : null}
          {tab === "products" ? (
            <ProductDesk
              products={products}
              onChanged={() => setRefreshKey((value) => value + 1)}
            />
          ) : null}
          {tab === "banner" ? (
            <BannerForm key={banner ? `${banner.title}-${banner.active}` : "default"} banner={banner} onChanged={() => setRefreshKey((value) => value + 1)} />
          ) : null}
          {tab === "team" && access.role === "owner" ? (
            <TeamPanel access={access} onChanged={() => setRefreshKey((value) => value + 1)} />
          ) : null}
        </>
      ) : null}
    </main>
  );
}

function TabButton({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button type="button" className={active ? btnPrimary : btnLine} onClick={onClick}>
      {children}
    </button>
  );
}

function ClaimForm({ onClaimed }: { onClaimed: () => void }) {
  const [phone, setPhone] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const result = await claimOffice({ data: { phone } });
      if (!result.ok) {
        setError(result.error);
        setBusy(false);
        return;
      }
      onClaimed();
    } catch (err) {
      setError(messageOf(err));
      setBusy(false);
    }
  }

  return (
    <form className="mt-6 max-w-lg rounded-lg border border-line bg-snow p-4" onSubmit={onSubmit}>
      <h2 className="font-display text-3xl font-semibold text-navy">Set up the office</h2>
      <p className="mt-2 text-sm text-ink">
        This can only be done once. The first person to confirm the business WhatsApp number becomes the
        administrator. Do it yourself before you share the staff link.
      </p>
      <label className="mt-4 block">
        <span className={labelClass}>Business WhatsApp number</span>
        <input className={fieldClass} value={phone} onChange={(event) => setPhone(event.target.value)} inputMode="tel" required />
      </label>
      {error ? (
        <p className="mt-3 text-sm font-semibold text-navy" role="alert">
          {error}
        </p>
      ) : null}
      <button type="submit" className={`${btnSun} mt-4`} disabled={busy}>
        {busy ? "Saving…" : "Become the office administrator"}
      </button>
    </form>
  );
}

function EnquiryList({ enquiries, onChanged }: { enquiries: Enquiry[]; onChanged: () => void }) {
  const [error, setError] = useState<string | null>(null);
  const [savingId, setSavingId] = useState<string | null>(null);

  if (enquiries.length === 0) {
    return <p className="mt-6 rounded-lg border border-line bg-snow p-4 text-sm text-muted">No enquiries yet.</p>;
  }

  return (
    <div className="mt-4 space-y-3">
      {error ? (
        <p className="text-sm font-semibold text-navy" role="alert">
          {error}
        </p>
      ) : null}
      {enquiries.map((enquiry) => {
        const whatsapp = customerWhatsApp(enquiry.phone, enquiry.reference);
        return (
          <article key={enquiry.id} className="rounded-lg border border-line bg-snow p-4">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <p className="font-semibold text-navy">
                  {enquiry.name} · <span className="tabular-nums">{enquiry.reference}</span>
                </p>
                <p className="text-sm text-muted">{enquiry.createdAt.replace("T", " ").replace("Z", " UTC")}</p>
              </div>
              <label className="text-sm">
                <span className="sr-only">Status</span>
                <select
                  className={fieldClass}
                  value={enquiry.status}
                  disabled={savingId === enquiry.id}
                  onChange={(event) => {
                    const status = event.target.value;
                    setSavingId(enquiry.id);
                    setError(null);
                    void updateEnquiryStatus({ data: { id: enquiry.id, status } })
                      .then((result) => {
                        if (!result.ok) setError(result.error);
                        else onChanged();
                      })
                      .catch((err: unknown) => setError(messageOf(err)))
                      .finally(() => setSavingId(null));
                  }}
                >
                  {ENQUIRY_STATUSES.map((status) => (
                    <option key={status.id} value={status.id}>
                      {status.label}
                    </option>
                  ))}
                </select>
              </label>
            </div>
            <p className="mt-2 text-sm">
              <span className="font-semibold text-navy">{projectLabel(enquiry.projectType)}</span>
              {" · "}
              {enquiry.location}
              {" · "}
              <a className="font-semibold text-green" href={`tel:${enquiry.phone.replace(/\s/g, "")}`}>
                {enquiry.phone}
              </a>
            </p>
            <p className="mt-2 text-sm text-ink">{enquiry.requirements}</p>
            {enquiry.products.length > 0 ? (
              <p className="mt-2 text-sm text-muted">{enquiry.products.map((product) => product.name).join(", ")}</p>
            ) : null}
            {whatsapp ? (
              <a className="mt-3 inline-flex text-sm font-semibold text-green underline-offset-2 hover:underline" href={whatsapp} target="_blank" rel="noopener noreferrer">
                Reply on WhatsApp
              </a>
            ) : null}
          </article>
        );
      })}
    </div>
  );
}

function ProductDesk({ products, onChanged }: { products: Product[]; onChanged: () => void }) {
  const [draft, setDraft] = useState<Draft | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  function edit(product: Product) {
    setDraft({
      id: product.id,
      name: product.name,
      category: product.category,
      summary: product.summary,
      description: product.description,
      specsText: product.specs.map((spec) => `${spec.label} | ${spec.value}`).join("\n"),
      priceLabel: product.priceLabel ?? "",
      availability: product.availability,
      imageUrl: product.imageUrl,
      featured: product.featured,
      sortOrder: product.sortOrder,
    });
    setError(null);
  }

  async function onSave(event: FormEvent) {
    event.preventDefault();
    if (!draft) return;
    setBusy(true);
    setError(null);
    try {
      const result = await saveProduct({ data: draft });
      if (!result.ok) {
        setError(result.error);
        setBusy(false);
        return;
      }
      setDraft(null);
      onChanged();
    } catch (err) {
      setError(messageOf(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_1.1fr]">
      <div className="space-y-2">
        <button
          type="button"
          className={btnSun}
          onClick={() => {
            setDraft({
              id: null,
              name: "",
              category: "panels",
              summary: "",
              description: "",
              specsText: "",
              priceLabel: "",
              availability: "on_request",
              imageUrl: "/media/panels.jpg",
              featured: false,
              sortOrder: products.length + 1,
            });
            setError(null);
          }}
        >
          Add product
        </button>
        {products.map((product) => (
          <button
            key={product.id}
            type="button"
            onClick={() => edit(product)}
            className="flex w-full items-center gap-3 rounded-lg border border-line bg-snow p-3 text-left"
          >
            <img src={safeImage(product.imageUrl)} alt="" className="h-14 w-14 object-contain" />
            <span>
              <span className="block font-semibold text-navy">{product.name}</span>
              <span className="block text-xs text-muted">
                {categoryLabel(product.category)} · {product.priceLabel ?? "Price on request"} ·{" "}
                {availabilityLabel(product.availability)}
              </span>
            </span>
          </button>
        ))}
      </div>
      {draft ? (
        <form className="rounded-lg border border-line bg-snow p-4" onSubmit={onSave}>
          <h2 className="font-display text-3xl font-semibold text-navy">{draft.id ? "Edit product" : "New product"}</h2>
          <label className="mt-3 block">
            <span className={labelClass}>Name</span>
            <input className={fieldClass} value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} required />
          </label>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <label>
              <span className={labelClass}>Category</span>
              <select className={fieldClass} value={draft.category} onChange={(event) => setDraft({ ...draft, category: event.target.value })}>
                {CATEGORIES.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.label}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <span className={labelClass}>Availability</span>
              <select className={fieldClass} value={draft.availability} onChange={(event) => setDraft({ ...draft, availability: event.target.value })}>
                {AVAILABILITY.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.label}
                  </option>
                ))}
              </select>
            </label>
          </div>
          <label className="mt-3 block">
            <span className={labelClass}>Price (leave blank for price on request)</span>
            <input className={fieldClass} value={draft.priceLabel} onChange={(event) => setDraft({ ...draft, priceLabel: event.target.value })} placeholder="Enter only a price you have confirmed" />
          </label>
          <label className="mt-3 block">
            <span className={labelClass}>Summary</span>
            <input className={fieldClass} value={draft.summary} onChange={(event) => setDraft({ ...draft, summary: event.target.value })} required />
          </label>
          <label className="mt-3 block">
            <span className={labelClass}>Description</span>
            <textarea className={`${fieldClass} min-h-28 py-3`} value={draft.description} onChange={(event) => setDraft({ ...draft, description: event.target.value })} required />
          </label>
          <label className="mt-3 block">
            <span className={labelClass}>Specifications, one per line: Label | Value</span>
            <textarea className={`${fieldClass} min-h-24 py-3`} value={draft.specsText} onChange={(event) => setDraft({ ...draft, specsText: event.target.value })} />
          </label>
          <p className={labelClass}>Photo</p>
          <div className="flex flex-wrap gap-2">
            {MEDIA_LIBRARY.map((media) => (
              <button
                key={media.src}
                type="button"
                className={draft.imageUrl === media.src ? "rounded-md border-2 border-green p-1" : "rounded-md border border-line p-1"}
                onClick={() => setDraft({ ...draft, imageUrl: media.src })}
              >
                <img src={media.src} alt={media.label} className="h-12 w-12 object-contain" />
              </button>
            ))}
          </div>
          <label className="mt-3 block">
            <span className={labelClass}>Or paste an https image link</span>
            <input className={fieldClass} value={draft.imageUrl} onChange={(event) => setDraft({ ...draft, imageUrl: event.target.value })} />
          </label>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <label className="flex min-h-11 items-center gap-2 text-sm font-semibold text-navy">
              <input type="checkbox" checked={draft.featured} onChange={(event) => setDraft({ ...draft, featured: event.target.checked })} />
              Show on the home page
            </label>
            <label>
              <span className={labelClass}>Sort order</span>
              <input
                className={fieldClass}
                type="number"
                min={0}
                max={999}
                value={draft.sortOrder}
                onChange={(event) => setDraft({ ...draft, sortOrder: Number(event.target.value) })}
              />
            </label>
          </div>
          {error ? (
            <p className="mt-3 text-sm font-semibold text-navy" role="alert">
              {error}
            </p>
          ) : null}
          <div className="mt-4 flex flex-wrap gap-2">
            <button type="submit" className={btnPrimary} disabled={busy}>
              {busy ? "Saving…" : "Save product"}
            </button>
            {draft.id ? (
              <button
                type="button"
                className={btnLine}
                onClick={() => {
                  if (!draft.id) return;
                  if (!window.confirm("Remove this product from the catalogue?")) return;
                  setBusy(true);
                  void deleteProduct({ data: { id: draft.id } })
                    .then(() => {
                      setDraft(null);
                      onChanged();
                    })
                    .catch((err: unknown) => setError(messageOf(err)))
                    .finally(() => setBusy(false));
                }}
              >
                Delete
              </button>
            ) : null}
          </div>
        </form>
      ) : (
        <p className="rounded-lg border border-dashed border-line p-4 text-sm text-muted">Select a product to edit its price, photo, stock or wording.</p>
      )}
    </div>
  );
}

function BannerForm({ banner, onChanged }: { banner: Banner | null; onChanged: () => void }) {
  const [eyebrow, setEyebrow] = useState(banner?.eyebrow ?? DEFAULT_BANNER.eyebrow);
  const [title, setTitle] = useState(banner?.title ?? DEFAULT_BANNER.title);
  const [body, setBody] = useState(banner?.body ?? DEFAULT_BANNER.body);
  const [active, setActive] = useState(banner?.active ?? true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setSaved(false);
    setError(null);
    try {
      const result = await saveBanner({ data: { eyebrow, title, body, active } });
      if (!result.ok) {
        setError(result.error);
        setBusy(false);
        return;
      }
      setSaved(true);
      onChanged();
    } catch (err) {
      setError(messageOf(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="mt-4 max-w-2xl rounded-lg border border-line bg-snow p-4" onSubmit={onSubmit}>
      <h2 className="font-display text-3xl font-semibold text-navy">Home banner</h2>
      <label className="mt-3 block">
        <span className={labelClass}>Eyebrow</span>
        <input className={fieldClass} value={eyebrow} onChange={(event) => setEyebrow(event.target.value)} required />
      </label>
      <label className="mt-3 block">
        <span className={labelClass}>Headline</span>
        <textarea className={`${fieldClass} min-h-24 py-3`} value={title} onChange={(event) => setTitle(event.target.value)} required />
      </label>
      <label className="mt-3 block">
        <span className={labelClass}>Supporting text</span>
        <textarea className={`${fieldClass} min-h-28 py-3`} value={body} onChange={(event) => setBody(event.target.value)} required />
      </label>
      <label className="mt-3 flex min-h-11 items-center gap-2 text-sm font-semibold text-navy">
        <input type="checkbox" checked={active} onChange={(event) => setActive(event.target.checked)} />
        Show this banner on the home page
      </label>
      {error ? (
        <p className="mt-3 text-sm font-semibold text-navy" role="alert">
          {error}
        </p>
      ) : null}
      {saved ? <p className="mt-3 text-sm font-semibold text-green">Banner saved.</p> : null}
      <button type="submit" className={`${btnPrimary} mt-4`} disabled={busy}>
        {busy ? "Saving…" : "Save banner"}
      </button>
    </form>
  );
}

function TeamPanel({ access, onChanged }: { access: OfficeAccess; onChanged: () => void }) {
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onInvite(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const result = await inviteStaff({ data: { email } });
      if (!result.ok) {
        setError(result.error);
        setBusy(false);
        return;
      }
      setEmail("");
      onChanged();
    } catch (err) {
      setError(messageOf(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mt-4 max-w-xl space-y-4">
      <form className="rounded-lg border border-line bg-snow p-4" onSubmit={onInvite}>
        <h2 className="font-display text-3xl font-semibold text-navy">Invite staff</h2>
        <p className="mt-2 text-sm text-muted">They sign in with this email, then the desk opens for them.</p>
        <label className="mt-3 block">
          <span className={labelClass}>Email</span>
          <input className={fieldClass} type="email" value={email} onChange={(event) => setEmail(event.target.value)} required />
        </label>
        {error ? (
          <p className="mt-3 text-sm font-semibold text-navy" role="alert">
            {error}
          </p>
        ) : null}
        <button type="submit" className={`${btnPrimary} mt-4`} disabled={busy}>
          {busy ? "Saving…" : "Send invite"}
        </button>
      </form>
      <ul className="space-y-2">
        {access.team.map((member) => (
          <li key={member.userId} className="flex items-center justify-between gap-3 rounded-lg border border-line bg-snow px-3 py-3 text-sm">
            <span>
              <span className="font-semibold text-navy">{member.email}</span>
              <span className="text-muted"> · {member.role}</span>
            </span>
            {member.role === "staff" ? (
              <button
                type="button"
                className="font-semibold text-green"
                onClick={() => {
                  void removeStaff({ data: { userId: member.userId } })
                    .then((result) => {
                      if (!result.ok) setError(result.error);
                      else onChanged();
                    })
                    .catch((err: unknown) => setError(messageOf(err)));
                }}
              >
                Remove
              </button>
            ) : null}
          </li>
        ))}
        {access.invites.map((invite) => (
          <li key={invite} className="flex items-center justify-between gap-3 rounded-lg border border-line bg-snow px-3 py-3 text-sm">
            <span>
              <span className="font-semibold text-navy">{invite}</span>
              <span className="text-muted"> · invited</span>
            </span>
            <button
              type="button"
              className="font-semibold text-green"
              onClick={() => {
                void removeInvite({ data: { email: invite } }).then(() => onChanged());
              }}
            >
              Cancel
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
