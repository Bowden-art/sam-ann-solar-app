import { createFileRoute, Link } from "@tanstack/react-router";
import { MapPin, Phone } from "lucide-react";
import { ADDRESS_FULL, MAP_URL, PHONE_DISPLAY, PHONE_TEL } from "@/lib/site";
import { btnGhost, btnPrimary, btnSun } from "@/lib/ui";
import { generalEnquiryMessage, whatsappLink } from "@/lib/whatsapp";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact · Sam-Ann Solar Investment" },
      {
        name: "description",
        content: "Call or WhatsApp +232 77 227530. Office: Main Port Loko Road, Gbaneh Bana, Lungi, Sierra Leone.",
      },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <main>
      <section className="bg-navy text-snow">
        <div className="h-1 bg-sun" />
        <div className="mx-auto max-w-6xl px-4 py-12">
          <p className="text-sm font-semibold tracking-wide text-sun uppercase">Our location</p>
          <h1 className="mt-2 font-display text-5xl font-semibold">Call or WhatsApp now</h1>
          <p className="mt-3 font-display text-5xl font-bold text-sun tabular-nums sm:text-6xl">{PHONE_DISPLAY}</p>
          <p className="mt-4 flex items-start gap-2 text-snow/80">
            <MapPin className="mt-1 size-5 shrink-0 text-sun" aria-hidden="true" />
            {ADDRESS_FULL}
          </p>
          <p className="mt-3 max-w-xl text-sm text-snow/70">
            Opening hours are not listed on the flyer. Call or WhatsApp to arrange a visit or a site conversation.
          </p>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <a className={btnSun} href={`tel:${PHONE_TEL}`}>
              <Phone className="size-4" aria-hidden="true" />
              Call the office
            </a>
            <a className={btnGhost} href={whatsappLink(generalEnquiryMessage())} target="_blank" rel="noopener noreferrer">
              WhatsApp us
            </a>
            <a className={btnGhost} href={MAP_URL} target="_blank" rel="noopener noreferrer">
              Open in maps
            </a>
          </div>
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="font-display text-4xl font-semibold text-navy">Prefer a written quotation?</h2>
        <p className="mt-2 max-w-xl text-ink">
          Send your name, phone, location and what you need to power. The enquiry is saved for the office, and you
          get a reference only after it goes through.
        </p>
        <Link to="/quote" className={`${btnPrimary} mt-6`}>
          Request a quote
        </Link>
      </section>
    </main>
  );
}
