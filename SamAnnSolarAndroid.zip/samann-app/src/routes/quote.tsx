import { useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { submitEnquiry } from "@/lib/solar.functions";
import { isProjectType, PROJECT_TYPES, projectLabel } from "@/lib/site";
import { useQuoteStore } from "@/lib/quote-store";
import { btnLine, btnPrimary, btnSun, fieldClass, labelClass } from "@/lib/ui";
import { quoteEnquiryMessage, whatsappLink } from "@/lib/whatsapp";

type QuoteSearch = { for?: string };

export const Route = createFileRoute("/quote")({
  validateSearch: (search: Record<string, unknown>): QuoteSearch => ({
    for: typeof search.for === "string" && isProjectType(search.for) ? search.for : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Request a quote · Sam-Ann Solar Investment" },
      {
        name: "description",
        content:
          "Request a Lumen Green solar quotation for a home, shop, office, farm, school or large project in Lungi.",
      },
    ],
  }),
  component: QuotePage,
});

function QuotePage() {
  const search = Route.useSearch();
  const items = useQuoteStore((state) => state.items);
  const remove = useQuoteStore((state) => state.remove);
  const clear = useQuoteStore((state) => state.clear);
  const [projectType, setProjectType] = useState(search.for && isProjectType(search.for) ? search.for : "homes");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [location, setLocation] = useState("");
  const [requirements, setRequirements] = useState("");
  const [website, setWebsite] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [reference, setReference] = useState<string | null>(null);
  const [sentProducts, setSentProducts] = useState<string[]>([]);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    setPending(true);
    try {
      const result = await submitEnquiry({
        data: {
          name,
          phone,
          location,
          projectType,
          requirements,
          productIds: items.map((item) => item.id),
          website,
        },
      });
      if (!result.ok) {
        setError(result.error);
        setPending(false);
        return;
      }
      setSentProducts(result.products.map((product) => product.name));
      setReference(result.reference);
      clear();
    } catch {
      setError("We could not save your enquiry. Please try again, or WhatsApp the office.");
      setPending(false);
    }
  }

  if (reference) {
    const message = quoteEnquiryMessage({
      name,
      phone,
      location,
      project: projectLabel(projectType),
      requirements,
      products: sentProducts,
      reference,
    });
    return (
      <main className="mx-auto max-w-2xl px-4 py-10">
        <div className="rounded-lg border border-green bg-snow p-6" role="status">
          <p className="text-sm font-semibold tracking-wide text-green uppercase">Enquiry received</p>
          <h1 className="mt-2 font-display text-5xl font-semibold text-navy">The office has your request</h1>
          <p className="mt-3 text-ink">
            Reference <span className="font-semibold text-navy tabular-nums">{reference}</span>. Sam-Ann Solar
            Investment will use the phone number you gave. You can also send the same details on WhatsApp.
          </p>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <a className={btnPrimary} href={whatsappLink(message)} target="_blank" rel="noopener noreferrer">
              Send on WhatsApp
            </a>
            <Link to="/products" className={btnLine}>
              Back to products
            </Link>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="mx-auto grid max-w-6xl gap-8 px-4 py-8 lg:grid-cols-[1fr_18rem]">
      <form className="rounded-lg border border-line bg-snow p-4 sm:p-6" onSubmit={onSubmit}>
        <p className="text-sm font-semibold tracking-wide text-green uppercase">Quotation</p>
        <h1 className="font-display text-5xl font-semibold text-navy">Request a quote</h1>
        <p className="mt-2 text-sm text-muted">
          For homes, shops, offices, farms, schools and large projects. Nothing is sent until this form saves.
        </p>

        <fieldset className="mt-6">
          <legend className={labelClass}>What is the power for?</legend>
          <div className="grid gap-2 sm:grid-cols-2">
            {PROJECT_TYPES.map((project) => (
              <label
                key={project.id}
                className={
                  projectType === project.id
                    ? "flex min-h-11 cursor-pointer items-center gap-2 rounded-md border border-green bg-green/10 px-3 py-2"
                    : "flex min-h-11 cursor-pointer items-center gap-2 rounded-md border border-line px-3 py-2"
                }
              >
                <input
                  type="radio"
                  name="project"
                  value={project.id}
                  checked={projectType === project.id}
                  onChange={() => setProjectType(project.id)}
                />
                <span>
                  <span className="block text-sm font-semibold text-navy">{project.label}</span>
                  <span className="block text-xs text-muted">{project.blurb}</span>
                </span>
              </label>
            ))}
          </div>
        </fieldset>

        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <label className="block">
            <span className={labelClass}>Your name</span>
            <input className={fieldClass} value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" required />
          </label>
          <label className="block">
            <span className={labelClass}>Phone / WhatsApp</span>
            <input
              className={fieldClass}
              value={phone}
              onChange={(event) => setPhone(event.target.value)}
              autoComplete="tel"
              inputMode="tel"
              required
            />
          </label>
        </div>
        <label className="mt-4 block">
          <span className={labelClass}>Location</span>
          <input
            className={fieldClass}
            value={location}
            onChange={(event) => setLocation(event.target.value)}
            placeholder="Town or area, for example Gbaneh Bana"
            autoComplete="address-level2"
            required
          />
        </label>
        <label className="mt-4 block">
          <span className={labelClass}>What do you need to power?</span>
          <textarea
            className={`${fieldClass} min-h-32 py-3`}
            value={requirements}
            onChange={(event) => setRequirements(event.target.value)}
            placeholder="Example: a shop with lights and a freezer, or a home that needs power in the evening."
            required
          />
        </label>
        <label className="sr-only" aria-hidden="true">
          Website
          <input tabIndex={-1} autoComplete="off" value={website} onChange={(event) => setWebsite(event.target.value)} />
        </label>
        {error ? (
          <p className="mt-4 rounded-md border border-sun bg-sun/20 px-3 py-2 text-sm font-semibold text-navy" role="alert">
            {error}
          </p>
        ) : null}
        <button type="submit" className={`${btnPrimary} mt-5 w-full sm:w-auto`} disabled={pending}>
          {pending ? "Sending enquiry…" : "Submit enquiry"}
        </button>
      </form>

      <aside className="h-fit rounded-lg border border-line bg-snow p-4">
        <h2 className="font-display text-2xl font-semibold text-navy">Selected products</h2>
        {items.length === 0 ? (
          <p className="mt-2 text-sm text-muted">None yet. A general enquiry is fine, or add products first.</p>
        ) : (
          <ul className="mt-3 space-y-2">
            {items.map((item) => (
              <li key={item.id} className="flex items-start justify-between gap-2 text-sm">
                <span className="font-semibold text-navy">{item.name}</span>
                <button type="button" className="shrink-0 text-green underline-offset-2 hover:underline" onClick={() => remove(item.id)}>
                  Remove
                </button>
              </li>
            ))}
          </ul>
        )}
        <Link to="/products" className={`${btnLine} mt-4 w-full`}>
          Browse products
        </Link>
        <a
          className={`${btnSun} mt-2 w-full`}
          href={whatsappLink(
            quoteEnquiryMessage({
              project: projectLabel(projectType),
              products: items.map((item) => item.name),
              requirements,
              name,
              phone,
              location,
            }),
          )}
          target="_blank"
          rel="noopener noreferrer"
        >
          WhatsApp instead
        </a>
      </aside>
    </main>
  );
}
