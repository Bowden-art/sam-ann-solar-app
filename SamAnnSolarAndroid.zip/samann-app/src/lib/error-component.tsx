import type { ErrorComponentProps } from "@tanstack/react-router";
import { TriangleAlert } from "lucide-react";

const FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";

function errorMessage(error: unknown): string {
  if (error instanceof Error && error.message) return error.message;
  if (typeof error === "string" && error) return error;
  return FALLBACK_MESSAGE;
}

export function AppErrorComponent({ error }: ErrorComponentProps) {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-3 bg-navy px-6 text-center text-snow">
      <span className="text-sun" aria-hidden="true">
        <TriangleAlert className="size-10" strokeWidth={2} />
      </span>
      <h1 className="font-display text-4xl font-semibold">Something went wrong</h1>
      <p className="max-w-md text-sm break-words text-snow/80">{errorMessage(error)}</p>
      <a className="mt-2 text-sm font-semibold text-sun underline-offset-2 hover:underline" href="/">
        Back to the home page
      </a>
    </main>
  );
}
