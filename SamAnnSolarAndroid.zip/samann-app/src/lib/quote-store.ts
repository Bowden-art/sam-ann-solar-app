import { create } from "zustand";

export type QuoteItem = { id: string; name: string };

const KEY = "samann-quote-v1";

function readItems(): QuoteItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const items: QuoteItem[] = [];
    for (const entry of parsed) {
      if (!entry || typeof entry !== "object") continue;
      const id = "id" in entry && typeof entry.id === "string" ? entry.id : "";
      const name = "name" in entry && typeof entry.name === "string" ? entry.name : "";
      if (id && name) items.push({ id, name });
    }
    return items.slice(0, 20);
  } catch {
    return [];
  }
}

function writeItems(items: QuoteItem[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(KEY, JSON.stringify(items));
}

type QuoteState = {
  items: QuoteItem[];
  ready: boolean;
  hydrate: () => void;
  add: (item: QuoteItem) => void;
  remove: (id: string) => void;
  clear: () => void;
};

export const useQuoteStore = create<QuoteState>((set, get) => ({
  items: [],
  ready: false,
  hydrate: () => {
    if (get().ready) return;
    set({ items: readItems(), ready: true });
  },
  add: (item) => {
    const base = get().ready ? get().items : readItems();
    const items = base.some((entry) => entry.id === item.id) ? base : [...base, item].slice(0, 20);
    writeItems(items);
    set({ items, ready: true });
  },
  remove: (id) => {
    const base = get().ready ? get().items : readItems();
    const items = base.filter((entry) => entry.id !== id);
    writeItems(items);
    set({ items, ready: true });
  },
  clear: () => {
    writeItems([]);
    set({ items: [], ready: true });
  },
}));
