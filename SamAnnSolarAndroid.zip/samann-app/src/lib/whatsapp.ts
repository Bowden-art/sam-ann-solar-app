import { COMPANY, WHATSAPP_NUMBER } from "@/lib/site";

export function whatsappLink(message: string): string {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

export function generalEnquiryMessage(): string {
  return `Hello ${COMPANY}, I would like to enquire about Lumen Green solar solutions in Lungi.`;
}

export function productEnquiryMessage(productName: string): string {
  return [
    `Hello ${COMPANY},`,
    `I would like a quotation for: ${productName}.`,
    "",
    "My name:",
    "Phone:",
    "Location:",
    "What I need to power:",
  ].join("\n");
}

export function quoteEnquiryMessage(input: {
  name?: string;
  phone?: string;
  location?: string;
  project?: string;
  requirements?: string;
  products?: string[];
  reference?: string;
}): string {
  const lines = [
    `Hello ${COMPANY},`,
    "I would like a quotation for Lumen Green solar solutions.",
  ];
  if (input.products && input.products.length > 0) {
    lines.push("", "Products:");
    for (const name of input.products) lines.push(`- ${name}`);
  }
  if (input.project) lines.push("", `Project type: ${input.project}`);
  if (input.requirements) lines.push("", `Requirements: ${input.requirements}`);
  if (input.name) lines.push("", `Name: ${input.name}`);
  if (input.phone) lines.push(`Phone: ${input.phone}`);
  if (input.location) lines.push(`Location: ${input.location}`);
  if (input.reference) lines.push("", `Enquiry reference: ${input.reference}`);
  return lines.join("\n");
}

/** Best-effort wa.me link for a customer number typed into an enquiry. */
export function customerWhatsApp(phone: string, reference: string): string | null {
  let digits = phone.replace(/\D/g, "");
  if (digits.startsWith("00")) digits = digits.slice(2);
  if (digits.startsWith("0")) digits = `232${digits.slice(1)}`;
  if (digits.length === 8) digits = `232${digits}`;
  if (digits.length < 10 || digits.length > 15) return null;
  const text = `Hello, this is ${COMPANY} following up on enquiry ${reference}.`;
  return `https://wa.me/${digits}?text=${encodeURIComponent(text)}`;
}
