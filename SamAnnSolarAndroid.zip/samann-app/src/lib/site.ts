export const COMPANY = "Sam-Ann Solar Investment";
export const PHONE_DISPLAY = "+232 77 227530";
export const PHONE_TEL = "+23277227530";
export const WHATSAPP_NUMBER = "23277227530";
export const ADDRESS_LINE = "Main Port Loko Road, Gbaneh Bana, Lungi";
export const ADDRESS_FULL = "Main Port Loko Road, Gbaneh Bana, Lungi, Sierra Leone";
export const MAP_URL = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(ADDRESS_FULL)}`;

export const DEFAULT_BANNER = {
  eyebrow: "Official Agent for Lumen Green at Lungi",
  title: "Power Your Home, Business & Projects with Lumen Green Solar Solutions.",
  body: "Reliable, efficient and long lasting. High quality solar products for homes, shops, businesses, farms, schools, offices and large projects in Lungi and surrounding areas.",
};

export const CATEGORIES = [
  { id: "panels", label: "Solar panels", blurb: "580W–600W PV modules" },
  { id: "batteries", label: "Energy storage batteries", blurb: "15kWh and 16kWh LiFePO4" },
  { id: "inverters", label: "Inverters", blurb: "4–15kW three-phase" },
  { id: "mounting", label: "Mounting systems", blurb: "Rails and accessories" },
  { id: "cables", label: "Solar cables and MC4", blurb: "Cables and connectors" },
  { id: "kits", label: "Integrated solar kits", blurb: "Homes, businesses, projects" },
] as const;

export type CategoryId = (typeof CATEGORIES)[number]["id"];

export const PROJECT_TYPES = [
  { id: "homes", label: "Homes", blurb: "Reliable power for your family" },
  { id: "shops", label: "Shops", blurb: "Keep your business running smoothly" },
  { id: "offices", label: "Businesses & offices", blurb: "Efficient and scalable solutions" },
  { id: "farms", label: "Farms", blurb: "Power for agriculture and rural development" },
  { id: "schools", label: "Schools", blurb: "Clean and stable energy supply" },
  { id: "projects", label: "Large projects", blurb: "Industrial and commercial needs" },
] as const;

export type ProjectTypeId = (typeof PROJECT_TYPES)[number]["id"];

export const SERVICES = [
  {
    title: "Product sales",
    body: "Lumen Green panels, batteries, inverters, mounting, cables and kits from the Lungi office.",
  },
  {
    title: "Installation support",
    body: "Help planning how the equipment goes in for homes, shops and larger sites.",
  },
  {
    title: "Technical support",
    body: "Professional guidance to help your project succeed.",
  },
  {
    title: "After-sales support",
    body: "Ongoing support and assistance after the system is supplied.",
  },
  {
    title: "Delivery",
    body: "Delivery arranged from Main Port Loko Road, Gbaneh Bana, Lungi.",
  },
  {
    title: "Flexible solutions",
    body: "Systems matched to different energy needs, from a family home to a large project.",
  },
] as const;

export const AVAILABILITY = [
  { id: "available", label: "Available" },
  { id: "limited", label: "Limited stock" },
  { id: "on_request", label: "Confirm with office" },
  { id: "unavailable", label: "Out of stock" },
] as const;

export type AvailabilityId = (typeof AVAILABILITY)[number]["id"];

export const ENQUIRY_STATUSES = [
  { id: "new", label: "New" },
  { id: "contacted", label: "Contacted" },
  { id: "quoted", label: "Quoted" },
  { id: "closed", label: "Closed" },
] as const;

export const MEDIA_LIBRARY = [
  { src: "/media/panels.jpg", label: "Solar panels" },
  { src: "/media/batteries.jpg", label: "Batteries" },
  { src: "/media/inverters.jpg", label: "Inverters" },
  { src: "/media/mounting.jpg", label: "Mounting" },
  { src: "/media/cables.jpg", label: "Cables and MC4" },
  { src: "/media/kits.jpg", label: "Integrated kits" },
  { src: "/media/hero.jpg", label: "Product lineup" },
] as const;

export function categoryLabel(id: string): string {
  return CATEGORIES.find((c) => c.id === id)?.label ?? id;
}

export function projectLabel(id: string): string {
  return PROJECT_TYPES.find((p) => p.id === id)?.label ?? id;
}

export function availabilityLabel(id: string): string {
  return AVAILABILITY.find((a) => a.id === id)?.label ?? id;
}

export function isProjectType(id: string): id is ProjectTypeId {
  return PROJECT_TYPES.some((p) => p.id === id);
}

export function isCategory(id: string): id is CategoryId {
  return CATEGORIES.some((c) => c.id === id);
}

export function isAvailability(id: string): id is AvailabilityId {
  return AVAILABILITY.some((a) => a.id === id);
}

export function safeImage(url: string | null | undefined): string {
  if (!url) return "/media/panels.jpg";
  if (url.startsWith("/media/") && !url.includes("..") && !url.includes("\\")) return url;
  if (url.startsWith("https://") && url.length <= 500 && !url.includes(" ")) return url;
  return "/media/panels.jpg";
}
