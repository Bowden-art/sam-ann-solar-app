import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  isAvailability,
  isCategory,
  isProjectType,
  safeImage,
  type AvailabilityId,
  type CategoryId,
  type ProjectTypeId,
} from "@/lib/site";

export type Spec = { label: string; name?: never; value: string };

export type Product = {
  id: string;
  slug: string;
  category: CategoryId;
  name: string;
  summary: string;
  description: string;
  specs: Spec[];
  priceLabel: string | null;
  availability: AvailabilityId;
  imageUrl: string;
  featured: boolean;
  sortOrder: number;
};

export type Banner = {
  id: string;
  eyebrow: string;
  title: string;
  body: string;
  active: boolean;
};

export type EnquiryProduct = { id: string; name: string };

export type Enquiry = {
  id: string;
  reference: string;
  name: string;
  phone: string;
  location: string;
  projectType: ProjectTypeId;
  requirements: string;
  products: EnquiryProduct[];
  status: "new" | "contacted" | "quoted" | "closed";
  createdAt: string;
};

export type OfficeAccess = {
  role: "owner" | "staff" | "none";
  email: string | null;
  needsSetup: boolean;
  team: { userId: string; email: string; role: string }[];
  invites: string[];
};

type ProductRow = {
  id: string;
  slug: string;
  category: string;
  name: string;
  summary: string;
  description: string;
  specs: unknown;
  price_label: string | null;
  availability: string;
  image_url: string;
  featured: boolean;
  sort_order: number;
};

type BannerRow = {
  id: string;
  eyebrow: string;
  title: string;
  body: string;
  active: boolean;
};

function asSpecs(value: unknown): Spec[] {
  let raw = value;
  if (typeof raw === "string") {
    try {
      raw = JSON.parse(raw) as unknown;
    } catch {
      return [];
    }
  }
  if (!Array.isArray(raw)) return [];
  const specs: Spec[] = [];
  for (const item of raw) {
    if (!item || typeof item !== "object") continue;
    const label = "label" in item && typeof item.label === "string" ? item.label : "";
    const specValue = "value" in item && typeof item.value === "string" ? item.value : "";
    if (label && specValue) specs.push({ label, value: specValue });
  }
  return specs;
}

function asEnquiryProducts(value: unknown): EnquiryProduct[] {
  let raw = value;
  if (typeof raw === "string") {
    try {
      raw = JSON.parse(raw) as unknown;
    } catch {
      return [];
    }
  }
  if (!Array.isArray(raw)) return [];
  const products: EnquiryProduct[] = [];
  for (const item of raw) {
    if (!item || typeof item !== "object") continue;
    const id = "id" in item && typeof item.id === "string" ? item.id : "";
    const name = "name" in item && typeof item.name === "string" ? item.name : "";
    if (id && name) products.push({ id, name });
  }
  return products;
}

function mapProduct(row: ProductRow): Product {
  return {
    id: row.id,
    slug: row.slug,
    category: isCategory(row.category) ? row.category : "kits",
    name: row.name,
    summary: row.summary,
    description: row.description,
    specs: asSpecs(row.specs),
    priceLabel: row.price_label,
    availability: isAvailability(row.availability) ? row.availability : "on_request",
    imageUrl: safeImage(row.image_url),
    featured: Boolean(row.featured),
    sortOrder: Number(row.sort_order) || 0,
  };
}

function mapBanner(row: BannerRow): Banner {
  return {
    id: row.id,
    eyebrow: row.eyebrow,
    title: row.title,
    body: row.body,
    active: Boolean(row.active),
  };
}

function clip(value: string, max: number): string {
  return value.trim().slice(0, max);
}

function parseSpecsText(text: string): Spec[] {
  const specs: Spec[] = [];
  for (const line of text.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const [labelPart, ...rest] = trimmed.split("|");
    const label = clip(labelPart ?? "", 60);
    const value = clip(rest.join("|"), 160);
    if (!label || !value) continue;
    specs.push({ label, value });
    if (specs.length >= 12) break;
  }
  return specs;
}

function slugify(name: string): string {
  const slug = name
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
  return slug || "product";
}

async function staffRole(userId: string): Promise<"owner" | "staff" | "none"> {
  const sql = await getSql();
  const rows = await sql<{ role: string }>`select role from staff where user_id = ${userId} limit 1`;
  const role = rows[0]?.role;
  if (role === "owner" || role === "staff") return role;
  return "none";
}

async function requireStaff(userId: string): Promise<"owner" | "staff"> {
  const role = await staffRole(userId);
  if (role === "none") throw new Error("This account is not on the Sam-Ann office list.");
  return role;
}

async function requireOwner(userId: string): Promise<void> {
  const role = await requireStaff(userId);
  if (role !== "owner") throw new Error("Only the office owner can change staff.");
}

async function userEmail(userId: string): Promise<string | null> {
  const sql = await getSql();
  const rows = await sql<{ email: string }>`select email from "user" where id = ${userId} limit 1`;
  return rows[0]?.email ?? null;
}

export const listCatalogue = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  const products = (
    await sql<ProductRow>`select id, slug, category, name, summary, description, specs, price_label, availability, image_url, featured, sort_order from products order by sort_order asc, name asc`
  ).map(mapProduct);
  const banners = await sql<BannerRow>`select id, eyebrow, title, body, active from banners where id = 'home' limit 1`;
  return {
    products,
    banner: banners[0] ? mapBanner(banners[0]) : null,
  };
});

export const getProduct = createServerFn({ method: "GET" })
  .validator((slug: string) => {
    if (typeof slug !== "string" || !slug || slug.length > 80) throw new Error("Invalid product");
    return slug;
  })
  .handler(async ({ data: slug }) => {
    const sql = await getSql();
    const rows = await sql<ProductRow>`select id, slug, category, name, summary, description, specs, price_label, availability, image_url, featured, sort_order from products where slug = ${slug} limit 1`;
    return rows[0] ? mapProduct(rows[0]) : null;
  });

type EnquiryInput = {
  name: string;
  phone: string;
  location: string;
  projectType: string;
  requirements: string;
  productIds: string[];
  website?: string;
};

export const submitEnquiry = createServerFn({ method: "POST" })
  .validator((input: EnquiryInput) => input)
  .handler(async ({ data }) => {
    if (typeof data?.website === "string" && data.website.trim()) {
      return {
        ok: false as const,
        error: "We could not save your enquiry. Please call or WhatsApp the office.",
      };
    }
    const name = clip(typeof data?.name === "string" ? data.name : "", 80);
    const phone = clip(typeof data?.phone === "string" ? data.phone : "", 30);
    const location = clip(typeof data?.location === "string" ? data.location : "", 120);
    const requirements = clip(typeof data?.requirements === "string" ? data.requirements : "", 2000);
    const projectType = typeof data?.projectType === "string" ? data.projectType : "";
    const digits = phone.replace(/\D/g, "");
    if (name.length < 2) return { ok: false as const, error: "Enter your name." };
    if (digits.length < 8) return { ok: false as const, error: "Enter a phone number we can call or WhatsApp." };
    if (location.length < 2) return { ok: false as const, error: "Enter your location." };
    if (!isProjectType(projectType)) return { ok: false as const, error: "Choose what the power is for." };
    if (requirements.length < 12) {
      return { ok: false as const, error: "Tell us a little more about what you need to power." };
    }
    const rawIds = Array.isArray(data?.productIds) ? data.productIds : [];
    const ids = rawIds.filter((id): id is string => typeof id === "string" && id.length > 0 && id.length < 80).slice(0, 20);

    try {
      const sql = await getSql();
      const catalogue = await sql<{ id: string; name: string }>`select id, name from products`;
      const products = ids
        .map((id) => catalogue.find((row) => row.id === id))
        .filter((row): row is { id: string; name: string } => Boolean(row));
      const id = crypto.randomUUID();
      const reference = `SA-${id.replaceAll("-", "").slice(0, 8).toUpperCase()}`;
      await sql`
        insert into enquiries (id, reference, name, phone, location, project_type, requirements, products, status)
        values (
          ${id},
          ${reference},
          ${name},
          ${phone},
          ${location},
          ${projectType},
          ${requirements},
          ${JSON.stringify(products)}::jsonb,
          'new'
        )
      `;
      return { ok: true as const, reference, products };
    } catch {
      return {
        ok: false as const,
        error: "We could not save your enquiry. Please try again, or WhatsApp the office.",
      };
    }
  });

export const getOfficeAccess = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<OfficeAccess> => {
    const sql = await getSql();
    const email = await userEmail(context.userId);
    if (email) {
      const invited = await sql<{ email: string }>`
        select email from staff_invites where lower(email) = lower(${email}) limit 1
      `;
      if (invited[0]) {
        await sql`
          insert into staff (user_id, email, role)
          select ${context.userId}, ${email}, 'staff'
          where not exists (select 1 from staff where user_id = ${context.userId})
        `;
        await sql`delete from staff_invites where lower(email) = lower(${email})`;
      }
    }
    const role = await staffRole(context.userId);
    const counts = await sql<{ n: number }>`select count(*)::int as n from staff`;
    const needsSetup = Number(counts[0]?.n ?? 0) === 0;
    if (role !== "owner") {
      return { role, email, needsSetup, team: [], invites: [] };
    }
    const team = await sql<{ user_id: string; email: string; role: string }>`
      select user_id, email, role from staff order by created_at asc
    `;
    const invites = await sql<{ email: string }>`select email from staff_invites order by created_at asc`;
    return {
      role,
      email,
      needsSetup,
      team: team.map((row) => ({ userId: row.user_id, email: row.email, role: row.role })),
      invites: invites.map((row) => row.email),
    };
  });

export const claimOffice = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { phone: string }) => input)
  .handler(async ({ context, data }) => {
    const digits = (data?.phone ?? "").replace(/\D/g, "");
    const okNumber = digits === "23277227530" || digits === "077227530" || digits === "77227530";
    if (!okNumber) {
      return { ok: false as const, error: "Enter the Sam-Ann WhatsApp number shown on the flyer to confirm this is the office." };
    }
    const email = await userEmail(context.userId);
    if (!email) return { ok: false as const, error: "Sign in before setting up the office." };
    const sql = await getSql();
    const inserted = await sql<{ user_id: string }>`
      insert into staff (user_id, email, role)
      select ${context.userId}, ${email}, 'owner'
      where not exists (select 1 from staff)
      returning user_id
    `;
    if (!inserted[0]) {
      return { ok: false as const, error: "The office already has an administrator. Ask them to invite your email." };
    }
    return { ok: true as const };
  });

export const listEnquiries = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireStaff(context.userId);
    const sql = await getSql();
    const rows = await sql<{
      id: string;
      reference: string;
      name: string;
      phone: string;
      location: string;
      project_type: string;
      requirements: string;
      products: unknown;
      status: string;
      created_at: string;
    }>`
      select id, reference, name, phone, location, project_type, requirements, products, status,
        to_char(created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as created_at
      from enquiries
      order by created_at desc
      limit 200
    `;
    const enquiries: Enquiry[] = rows.map((row) => ({
      id: row.id,
      reference: row.reference,
      name: row.name,
      phone: row.phone,
      location: row.location,
      projectType: isProjectType(row.project_type) ? row.project_type : "homes",
      requirements: row.requirements,
      products: asEnquiryProducts(row.products),
      status: row.status === "contacted" || row.status === "quoted" || row.status === "closed" ? row.status : "new",
      createdAt: row.created_at,
    }));
    return enquiries;
  });

export const updateEnquiryStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string; status: string }) => input)
  .handler(async ({ context, data }) => {
    await requireStaff(context.userId);
    const status = data?.status;
    if (status !== "new" && status !== "contacted" && status !== "quoted" && status !== "closed") {
      return { ok: false as const, error: "Unknown status." };
    }
    const id = typeof data?.id === "string" ? data.id : "";
    const sql = await getSql();
    const updated = await sql<{ id: string }>`
      update enquiries set status = ${status} where id = ${id} returning id
    `;
    if (!updated[0]) return { ok: false as const, error: "Enquiry not found." };
    return { ok: true as const };
  });

type SaveProductInput = {
  id: string | null;
  name: string;
  category: string;
  summary: string;
  description: string;
  specsText: string;
  priceLabel: string;
  availability: string;
  imageUrl: string;
  featured: boolean;
  sortOrder: number;
};

export const saveProduct = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: SaveProductInput) => input)
  .handler(async ({ context, data }) => {
    await requireStaff(context.userId);
    const name = clip(data?.name ?? "", 120);
    const summary = clip(data?.summary ?? "", 220);
    const description = clip(data?.description ?? "", 1500);
    const category = data?.category ?? "";
    const availability = data?.availability ?? "";
    const priceLabelRaw = clip(data?.priceLabel ?? "", 80);
    const priceLabel = priceLabelRaw.length > 0 ? priceLabelRaw : null;
    const imageUrl = safeImage(data?.imageUrl);
    const featured = Boolean(data?.featured);
    const sortOrder = Number.isFinite(data?.sortOrder) ? Math.max(0, Math.min(999, Math.round(data.sortOrder))) : 0;
    const specs = parseSpecsText(data?.specsText ?? "");
    if (name.length < 2) return { ok: false as const, error: "Enter a product name." };
    if (!isCategory(category)) return { ok: false as const, error: "Choose a category." };
    if (!isAvailability(availability)) return { ok: false as const, error: "Choose availability." };
    if (summary.length < 2) return { ok: false as const, error: "Enter a short summary." };
    if (description.length < 2) return { ok: false as const, error: "Enter a description." };
    if (data?.imageUrl && safeImage(data.imageUrl) === "/media/panels.jpg" && data.imageUrl !== "/media/panels.jpg") {
      return { ok: false as const, error: "Use a flyer photo or an https image link." };
    }

    const sql = await getSql();
    const specsJson = JSON.stringify(specs);
    if (data?.id) {
      const updated = await sql<{ id: string }>`
        update products set
          name = ${name},
          category = ${category},
          summary = ${summary},
          description = ${description},
          specs = ${specsJson}::jsonb,
          price_label = ${priceLabel},
          availability = ${availability},
          image_url = ${imageUrl},
          featured = ${featured},
          sort_order = ${sortOrder},
          updated_at = now()
        where id = ${data.id}
        returning id
      `;
      if (!updated[0]) return { ok: false as const, error: "Product not found." };
      return { ok: true as const, id: updated[0].id };
    }

    const base = slugify(name);
    let slug = base;
    for (let n = 1; n <= 30; n += 1) {
      const taken = await sql<{ id: string }>`select id from products where id = ${slug} or slug = ${slug} limit 1`;
      if (!taken[0]) break;
      slug = `${base}-${n + 1}`.slice(0, 70);
      if (n === 30) return { ok: false as const, error: "Choose a more specific product name." };
    }
    await sql`
      insert into products (
        id, slug, category, name, summary, description, specs, price_label, availability, image_url, featured, sort_order
      ) values (
        ${slug}, ${slug}, ${category}, ${name}, ${summary}, ${description},
        ${specsJson}::jsonb, ${priceLabel}, ${availability}, ${imageUrl}, ${featured}, ${sortOrder}
      )
    `;
    return { ok: true as const, id: slug };
  });

export const deleteProduct = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string }) => input)
  .handler(async ({ context, data }) => {
    await requireStaff(context.userId);
    const id = data?.id ?? "";
    const sql = await getSql();
    await sql`delete from products where id = ${id}`;
    return { ok: true as const };
  });

export const saveBanner = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { eyebrow: string; title: string; body: string; active: boolean }) => input)
  .handler(async ({ context, data }) => {
    await requireStaff(context.userId);
    const eyebrow = clip(data?.eyebrow ?? "", 140);
    const title = clip(data?.title ?? "", 200);
    const body = clip(data?.body ?? "", 700);
    if (eyebrow.length < 2 || title.length < 2 || body.length < 2) {
      return { ok: false as const, error: "Fill in the banner eyebrow, title and text." };
    }
    const sql = await getSql();
    await sql`
      insert into banners (id, eyebrow, title, body, active)
      values ('home', ${eyebrow}, ${title}, ${body}, ${Boolean(data?.active)})
      on conflict (id) do update set
        eyebrow = excluded.eyebrow,
        title = excluded.title,
        body = excluded.body,
        active = excluded.active
    `;
    return { ok: true as const };
  });

export const inviteStaff = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { email: string }) => input)
  .handler(async ({ context, data }) => {
    await requireOwner(context.userId);
    const email = clip(data?.email ?? "", 160).toLowerCase();
    if (!email.includes("@") || email.startsWith("@") || email.endsWith("@")) {
      return { ok: false as const, error: "Enter a valid staff email." };
    }
    const sql = await getSql();
    await sql`
      insert into staff_invites (email) values (${email})
      on conflict (email) do nothing
    `;
    return { ok: true as const };
  });

export const removeInvite = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { email: string }) => input)
  .handler(async ({ context, data }) => {
    await requireOwner(context.userId);
    const email = (data?.email ?? "").trim().toLowerCase();
    const sql = await getSql();
    await sql`delete from staff_invites where lower(email) = ${email}`;
    return { ok: true as const };
  });

export const removeStaff = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { userId: string }) => input)
  .handler(async ({ context, data }) => {
    await requireOwner(context.userId);
    const userId = data?.userId ?? "";
    if (!userId || userId === context.userId) {
      return { ok: false as const, error: "You cannot remove your own office access." };
    }
    const sql = await getSql();
    const removed = await sql<{ user_id: string }>`
      delete from staff where user_id = ${userId} and role = 'staff' returning user_id
    `;
    if (!removed[0]) return { ok: false as const, error: "That person is not removable staff." };
    return { ok: true as const };
  });

