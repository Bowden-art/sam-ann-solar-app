export const btn =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-md px-4 text-center text-sm font-semibold transition-colors duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sun disabled:cursor-not-allowed disabled:opacity-60";

export const btnPrimary = `${btn} bg-green text-snow hover:bg-green-deep`;
export const btnSun = `${btn} bg-sun text-navy hover:bg-sun/90`;
export const btnNavy = `${btn} bg-navy text-snow hover:bg-navy-soft`;
export const btnGhost = `${btn} border border-snow/40 bg-transparent text-snow hover:bg-snow/10`;
export const btnLine = `${btn} border border-line bg-snow text-navy hover:border-green`;

export const fieldClass =
  "min-h-11 w-full rounded-md border border-line bg-snow px-3 text-base text-navy outline-none transition-colors duration-200 placeholder:text-muted focus:border-green";

export const labelClass = "mb-1 block text-sm font-semibold text-navy";
