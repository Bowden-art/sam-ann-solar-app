import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { ADDRESS_LINE, PHONE_DISPLAY, PHONE_TEL } from "@/lib/site";
import { useQuoteStore } from "@/lib/quote-store";
import { generalEnquiryMessage, whatsappLink } from "@/lib/whatsapp";

const LINKS = [
  { to: "/", label: "Home", exact: true },
  { to: "/products", label: "Products", exact: false },
  { to: "/quote", label: "Quote", exact: false },
  { to: "/about", label: "About", exact: false },
  { to: "/contact", label: "Contact", exact: false },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const count = useQuoteStore((state) => state.items.length);
  const ready = useQuoteStore((state) => state.ready);
  const hydrate = useQuoteStore((state) => state.hydrate);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <header className="sticky top-0 z-40">
      <div className="bg-green text-snow">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-4 gap-y-1 px-4 py-2 text-sm">
          <p>{ADDRESS_LINE}</p>
          <a className="font-semibold underline-offset-2 hover:underline" href={`tel:${PHONE_TEL}`}>
            {PHONE_DISPLAY}
          </a>
        </div>
      </div>
      <div className="border-b border-sun bg-navy text-snow">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <Link to="/" className="shrink-0 rounded-md bg-snow px-2 py-1">
            <img
              src="/media/logo-samann.jpg"
              alt="Sam-Ann Solar Investment"
              className="h-11 w-auto max-w-40 object-contain sm:max-w-52"
            />
          </Link>
          <nav className="ml-auto hidden items-center gap-1 lg:flex" aria-label="Main">
            {LINKS.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                activeOptions={{ exact: link.exact }}
                className="rounded-md px-3 py-2 text-sm font-semibold text-snow/80 hover:bg-snow/10 hover:text-snow"
                activeProps={{ className: "rounded-md px-3 py-2 text-sm font-semibold text-sun hover:bg-snow/10" }}
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <Link
            to="/quote"
            className="ml-auto hidden min-h-11 items-center gap-2 rounded-md bg-sun px-3 text-sm font-semibold text-navy lg:ml-2 lg:inline-flex"
          >
            Quotation
            {ready && count > 0 ? (
              <span className="grid h-6 min-w-6 place-items-center rounded-full bg-navy px-1 text-xs text-sun tabular-nums">
                {count}
              </span>
            ) : null}
          </Link>
          <a
            className="hidden min-h-11 items-center rounded-md bg-green px-3 text-sm font-semibold text-snow lg:inline-flex"
            href={whatsappLink(generalEnquiryMessage())}
            target="_blank"
            rel="noopener noreferrer"
          >
            WhatsApp
          </a>
          <button
            type="button"
            className="ml-auto inline-flex h-11 w-11 items-center justify-center rounded-md border border-snow/30 lg:hidden"
            aria-expanded={open}
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((value) => !value)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
        {open ? (
          <nav className="space-y-1 border-t border-snow/15 px-4 py-3 lg:hidden" aria-label="Mobile">
            {LINKS.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="flex min-h-11 items-center rounded-md px-3 text-base font-semibold text-snow"
              >
                {link.label}
                {link.to === "/quote" && ready && count > 0 ? ` (${count})` : ""}
              </Link>
            ))}
            <a
              className="flex min-h-11 items-center rounded-md bg-green px-3 font-semibold text-snow"
              href={whatsappLink(generalEnquiryMessage())}
              target="_blank"
              rel="noopener noreferrer"
            >
              WhatsApp us
            </a>
          </nav>
        ) : null}
      </div>
    </header>
  );
}
