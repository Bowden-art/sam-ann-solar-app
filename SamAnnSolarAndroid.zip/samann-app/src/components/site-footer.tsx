import { Link } from "@tanstack/react-router";
import { ADDRESS_FULL, COMPANY, MAP_URL, PHONE_DISPLAY, PHONE_TEL, SERVICES } from "@/lib/site";
import { generalEnquiryMessage, whatsappLink } from "@/lib/whatsapp";

export function SiteFooter() {
  return (
    <footer className="mt-16 bg-navy text-snow">
      <div className="h-1 bg-sun" />
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:grid-cols-2 lg:grid-cols-4">
        <div className="sm:col-span-2">
          <p className="font-display text-3xl font-bold tracking-wide">SAM-ANN SOLAR INVESTMENT</p>
          <p className="mt-2 max-w-md text-sm text-snow/75">
            Official agent for Lumen Green at Lungi. Clean energy, brighter tomorrow.
          </p>
          <p className="mt-4 text-sm">{ADDRESS_FULL}</p>
        </div>
        <div>
          <p className="text-sm font-semibold text-sun">Services</p>
          <ul className="mt-3 space-y-2 text-sm text-snow/80">
            {SERVICES.slice(0, 5).map((service) => (
              <li key={service.title}>{service.title}</li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-sm font-semibold text-sun">Talk to the office</p>
          <div className="mt-3 flex flex-col items-start gap-2 text-sm">
            <a className="font-semibold underline-offset-2 hover:underline" href={`tel:${PHONE_TEL}`}>
              Call {PHONE_DISPLAY}
            </a>
            <a className="underline-offset-2 hover:underline" href={whatsappLink(generalEnquiryMessage())} target="_blank" rel="noopener noreferrer">
              WhatsApp {PHONE_DISPLAY}
            </a>
            <a className="underline-offset-2 hover:underline" href={MAP_URL} target="_blank" rel="noopener noreferrer">
              Open the map
            </a>
            <Link to="/admin" className="text-snow/70 underline-offset-2 hover:underline">
              Office desk
            </Link>
          </div>
        </div>
      </div>
      <div className="border-t border-snow/15 px-4 py-4 text-center text-xs text-snow/60">
        {COMPANY} · Shenzhen LumenGreen Technology Co., Ltd. products · Lungi, Sierra Leone
      </div>
    </footer>
  );
}
