import { Link } from "@tanstack/react-router";
import { availabilityLabel, categoryLabel, safeImage } from "@/lib/site";
import type { Product } from "@/lib/solar.functions";
import { useQuoteStore } from "@/lib/quote-store";
import { btnLine, btnPrimary } from "@/lib/ui";
import { productEnquiryMessage, whatsappLink } from "@/lib/whatsapp";

function availabilityClass(id: Product["availability"]): string {
  if (id === "available") return "bg-green/10 text-green";
  if (id === "limited") return "bg-sun text-navy";
  if (id === "unavailable") return "bg-line text-muted";
  return "bg-navy/10 text-navy";
}

export function ProductCard({ product }: { product: Product }) {
  const added = useQuoteStore((state) => state.items.some((item) => item.id === product.id));
  const add = useQuoteStore((state) => state.add);

  return (
    <article className="flex h-full flex-col overflow-hidden rounded-lg border border-line bg-snow">
      <Link to="/product/$slug" params={{ slug: product.slug }} className="block bg-paper">
        <div className="flex h-48 items-center justify-center p-3">
          <img
            src={safeImage(product.imageUrl)}
            alt={product.name}
            loading="lazy"
            decoding="async"
            className="max-h-full max-w-full object-contain"
          />
        </div>
      </Link>
      <div className="flex flex-1 flex-col gap-3 p-4">
        <p className="text-xs font-semibold tracking-wide text-green uppercase">{categoryLabel(product.category)}</p>
        <h2 className="font-display text-2xl leading-none font-semibold text-navy">
          <Link to="/product/$slug" params={{ slug: product.slug }} className="hover:text-green">
            {product.name}
          </Link>
        </h2>
        <p className="text-sm text-ink">{product.summary}</p>
        <div className="mt-auto flex flex-wrap items-center gap-2">
          <p className="text-sm font-semibold text-navy tabular-nums">{product.priceLabel ?? "Price on request"}</p>
          <span className={`rounded-md px-2 py-1 text-xs font-semibold ${availabilityClass(product.availability)}`}>
            {availabilityLabel(product.availability)}
          </span>
        </div>
        <div className="grid gap-2 sm:grid-cols-2">
          <button
            type="button"
            className={added ? btnLine : btnPrimary}
            onClick={() => add({ id: product.id, name: product.name })}
          >
            {added ? "Added to quote" : "Add to quote"}
          </button>
          <a
            className={btnLine}
            href={whatsappLink(productEnquiryMessage(product.name))}
            target="_blank"
            rel="noopener noreferrer"
          >
            WhatsApp
          </a>
        </div>
      </div>
    </article>
  );
}
