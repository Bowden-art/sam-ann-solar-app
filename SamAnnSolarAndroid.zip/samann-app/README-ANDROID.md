# Android app entry point

See [`ANDROID-APP-GUIDE.md`](ANDROID-APP-GUIDE.md) for the deployment prerequisite and APK build steps. The original Grok full-stack website source remains in this folder; the Android Studio project is under `android-app/`.
