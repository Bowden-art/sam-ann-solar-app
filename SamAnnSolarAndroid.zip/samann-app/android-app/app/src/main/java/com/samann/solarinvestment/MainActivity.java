package com.samann.solarinvestment;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.LinearLayout;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String PLACEHOLDER = "REPLACE-WITH-YOUR-DEPLOYED-WEBSITE.example";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(18, 59, 42));
        getWindow().setNavigationBarColor(Color.rgb(18, 59, 42));

        String siteUrl = BuildConfig.SITE_URL;
        if (siteUrl.contains(PLACEHOLDER) || !siteUrl.startsWith("https://")) {
            showSetupMessage();
            return;
        }

        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); // Required by the existing React website.
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, false);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
                String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
                String baseHost = Uri.parse(siteUrl).getHost();
                if (scheme.equals("https") && host.equalsIgnoreCase(baseHost)) return false;
                if (scheme.equals("http") || scheme.equals("https") || scheme.equals("whatsapp") || scheme.equals("tel") || scheme.equals("mailto")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (ActivityNotFoundException ignored) { }
                    return true;
                }
                return true;
            }
        });
        webView.loadUrl(siteUrl);
    }

    private void showSetupMessage() {
        TextView message = new TextView(this);
        message.setText("Sam-Ann Solar Investment\n\nApp setup is nearly ready. First deploy the website, then set SITE_URL to its HTTPS address and rebuild the APK. See ANDROID-APP-GUIDE.md.");
        message.setTextSize(18);
        message.setTextColor(Color.rgb(18, 59, 42));
        message.setPadding(48, 48, 48, 48);
        message.setGravity(android.view.Gravity.CENTER_VERTICAL);
        message.setBackgroundColor(Color.WHITE);
        setContentView(message);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
