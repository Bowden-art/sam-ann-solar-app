-- Sam-Ann Solar Investment catalogue, banners, enquiries, and office staff.
-- Prices are left empty on purpose. The office sets them. Nothing here invents a price.

create table if not exists products (
  id text primary key,
  slug text not null unique,
  category text not null,
  name text not null,
  summary text not null,
  description text not null,
  specs jsonb not null default '[]'::jsonb,
  price_label text,
  availability text not null default 'available',
  image_url text not null,
  featured boolean not null default false,
  sort_order integer not null default 0,
  updated_at timestamptz not null default now(),
  constraint products_category_chk check (
    category in ('panels', 'batteries', 'inverters', 'mounting', 'cables', 'kits')
  ),
  constraint products_availability_chk check (
    availability in ('available', 'limited', 'on_request', 'unavailable')
  )
);

create index if not exists products_category_idx on products (category);
create index if not exists products_sort_idx on products (sort_order);

create table if not exists banners (
  id text primary key,
  eyebrow text not null,
  title text not null,
  body text not null,
  active boolean not null default true
);

create table if not exists enquiries (
  id text primary key,
  reference text not null unique,
  name text not null,
  phone text not null,
  location text not null,
  project_type text not null,
  requirements text not null,
  products jsonb not null default '[]'::jsonb,
  status text not null default 'new',
  created_at timestamptz not null default now(),
  constraint enquiries_project_chk check (
    project_type in ('homes', 'shops', 'offices', 'farms', 'schools', 'projects')
  ),
  constraint enquiries_status_chk check (
    status in ('new', 'contacted', 'quoted', 'closed')
  )
);

create index if not exists enquiries_created_idx on enquiries (created_at desc);

create table if not exists staff (
  user_id text primary key,
  email text not null,
  role text not null,
  created_at timestamptz not null default now(),
  constraint staff_role_chk check (role in ('owner', 'staff'))
);

create table if not exists staff_invites (
  email text primary key,
  created_at timestamptz not null default now()
);

insert into banners (id, eyebrow, title, body, active) values (
  'home',
  'Official Agent for Lumen Green at Lungi',
  'Power Your Home, Business & Projects with Lumen Green Solar Solutions.',
  'Reliable, efficient and long lasting. High quality solar products for homes, shops, businesses, farms, schools, offices and large projects in Lungi and surrounding areas.',
  true
) on conflict (id) do nothing;

insert into products (
  id, slug, category, name, summary, description, specs, price_label, availability, image_url, featured, sort_order
) values
(
  'panel-580-600',
  '580w-600w-solar-pv-modules',
  'panels',
  '580W–600W Solar PV Modules',
  'Lumen Green solar PV modules in the 580W–600W class.',
  'Solar PV modules supplied by Sam-Ann Solar Investment, the official Lumen Green agent in Lungi. Lumen Green describes this class as high efficiency with a long lifespan. Suitable for homes, shops, businesses, farms, schools, offices and larger projects in Lungi and surrounding areas.',
  '[{"label":"Power class","value":"580W–600W"},{"label":"Product type","value":"Solar PV module"}]'::jsonb,
  null,
  'available',
  '/media/panels.jpg',
  true,
  1
),
(
  'battery-15kwh',
  '15kwh-lifepo4-battery',
  'batteries',
  '15kWh LiFePO4 Energy Storage Battery',
  '15kWh LiFePO4 battery from the Lumen Green storage range.',
  'LiFePO4 energy storage in a 15kWh capacity. Lumen Green describes these batteries as safe, reliable and long-lasting. Sam-Ann Solar Investment supplies them in Lungi. The photograph shows the Lumen Green storage cabinets from the office flyer.',
  '[{"label":"Chemistry","value":"LiFePO4"},{"label":"Capacity","value":"15kWh"}]'::jsonb,
  null,
  'available',
  '/media/batteries.jpg',
  true,
  2
),
(
  'battery-16kwh',
  '16kwh-lifepo4-battery',
  'batteries',
  '16kWh LiFePO4 Energy Storage Battery',
  '16kWh LiFePO4 battery from the Lumen Green storage range.',
  'LiFePO4 energy storage in a 16kWh capacity. Lumen Green describes these batteries as safe, reliable and long-lasting. Sam-Ann Solar Investment supplies them in Lungi. The photograph shows the Lumen Green storage cabinets from the office flyer.',
  '[{"label":"Chemistry","value":"LiFePO4"},{"label":"Capacity","value":"16kWh"}]'::jsonb,
  null,
  'available',
  '/media/batteries.jpg',
  true,
  3
),
(
  'inverter-4-15',
  '4kw-15kw-three-phase-inverters',
  'inverters',
  '4–15kW Three-Phase Inverters',
  'Three-phase inverters covering 4kW to 15kW.',
  'Three-phase inverters for Lumen Green solar systems. The range available through Sam-Ann Solar Investment in Lungi is 4kW–15kW. Lumen Green describes them as stable and efficient. The office matches a unit to the project when you request a quotation.',
  '[{"label":"Product type","value":"Three-phase inverter"},{"label":"Power range","value":"4kW–15kW"}]'::jsonb,
  null,
  'available',
  '/media/inverters.jpg',
  true,
  4
),
(
  'mounting-rails',
  'solar-mounting-rails-and-accessories',
  'mounting',
  'Solar Mounting Rails and Accessories',
  'Mounting rails and accessories for solar PV modules.',
  'Solar mounting rails and accessories supplied with Lumen Green installations. Lumen Green describes the system as durable and easy to install. Sam-Ann Solar Investment arranges them for roofs and projects in Lungi and surrounding areas.',
  '[{"label":"Product type","value":"Solar mounting system"},{"label":"Includes","value":"Mounting rails and accessories"}]'::jsonb,
  null,
  'available',
  '/media/mounting.jpg',
  false,
  5
),
(
  'cables-mc4',
  'solar-cables-and-mc4-connectors',
  'cables',
  'Solar Cables and MC4 Connectors',
  'Quality solar cables and MC4 connectors.',
  'Solar cables and MC4 connectors for Lumen Green installations, supplied by Sam-Ann Solar Investment in Lungi. The office confirms lengths and quantities with your quotation.',
  '[{"label":"Includes","value":"Solar cables"},{"label":"Connectors","value":"MC4 connectors"}]'::jsonb,
  null,
  'available',
  '/media/cables.jpg',
  false,
  6
),
(
  'integrated-kits',
  'integrated-solar-kits',
  'kits',
  'Integrated Solar Kits',
  'Complete solar systems for homes, businesses and large projects.',
  'Integrated Lumen Green solar kits arranged by Sam-Ann Solar Investment for homes, businesses and large projects. Panels, batteries, inverter, mounting and cabling are confirmed in the quotation. This listing does not assume a fixed kit size.',
  '[{"label":"Product type","value":"Integrated solar kit"},{"label":"Suitable for","value":"Homes, businesses and large projects"}]'::jsonb,
  null,
  'available',
  '/media/kits.jpg',
  true,
  7
)
on conflict (id) do nothing;
